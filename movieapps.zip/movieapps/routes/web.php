<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });


///////////////////////////////////////////////
// Saat user buka http://localhost:8000/home
// Laravel akan memanggil method home() di PageController
Route::get("/", "PageController@home");

// Saat user buka http://localhost:8000/movie
// Laravel akan memanggil method movie() di PageController
Route::get("/movie", "PageController@movie");
Route::get("/movie/addform", "PageController@movieaddform");
Route::post("/movie/save", "PageController@movieasave");


// // Saat user buka http://localhost:8000/genre
// // Laravel akan memanggil method genre() di PageController
Route::get("/genre", "PageController@genre");



