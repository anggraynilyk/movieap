<?php $__env->startSection('title', 'Movie'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <a href="/movie/addform" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Add Movie
        </a>
    </div>
    <div class="card-body">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>IMDB</th>
                    <th>Title</th>
                    <th>Genre</th>
                    <th>Year</th>
                    <th>Poster</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($idx + 1); ?></td>
                    <td><?php echo e($m->imdb); ?></td>
                    <td><?php echo e($m->title); ?></td>
                    <td><?php echo e($m->genre); ?></td>
                    <td><?php echo e($m->year); ?></td>
                    <td>
                        <?php if($m->poster): ?>
                            <img src="<?php echo e(asset('storage/posters/' . $m->poster)); ?>" width="80" alt="Poster">
                        <?php else: ?>
                            (no image)
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="/movie/edit/<?php echo e($m->id); ?>" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil-square"></i> Edit
                        </a>
                        <form action="/movie/delete/<?php echo e($m->id); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin mau hapus film ini?')">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\71220917_pwl_5\movieapps\resources\views/movie.blade.php ENDPATH**/ ?>