<?php $__env->startSection('title', 'Genre'); ?>
<?php $__env->startSection('content'); ?>
    <h3>GENRE</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, voluptatibus!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\71220917_pwl_5\movieapps\resources\views/genre.blade.php ENDPATH**/ ?>