
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <title>:home:</title>
  </head>
  <body>
    <div class="container-fluid">
        <!-- BARIS PERTAMA/HEADER -->
        <div class="row">
            <div class="col-md-12 py-2 bg-primary">
                <div class="dropdown float-right">
   <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <i class="bi bi-person-fill"></i> user
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">
        <div class="media">
  <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlciUyMHByb2ZpbGV8ZW58MHx8MHx8fDA%3D&fm=jpg&q=60&w=3000" 
   width="64" height="64"class="align-self-center mr-3" alt="...">
  
  <div class="media-body">
    <h5 class="mt-0">JOE</h5>
    <small><p class="mb-0"><i class="bi bi-clock"></i>PKL 13.00 WIB</p></small>
    <p></p>
    <p class="mb-0">is urient monteslus mus.</p>
  </div>
</div>
    </a>
    <a class="dropdown-item" href="#"><i class="bi bi-gear"></i> setting</a>
    <a class="dropdown-item" href="#"><i class="bi bi-box-arrow-right"></i>logout</a>
  </div>
</div>
            </div>
        </div>
        <!-- BARIS KEDUA/HEADER -->
        <div class="row">
            <div class="col-md-2 border vh-100">
                
    <div class="nav flex-column nav-pills mt-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" <?php echo e(($key == 'home')?'active':''); ?>href="/" role="tab" >Home</a>
      <a class="nav-link" <?php echo e(($key == 'home')?'active':''); ?>  href="/movie" role="tab" >movie</a>
      <a class="nav-link" <?php echo e(($key == 'home')?'active':''); ?> href="/Genre" role="tab" >Genre</a>
      <a class="nav-link" <?php echo e(($key == 'home')?'active':''); ?> href="/bioskop" role="tab" >bioskop</a>
    </div>
  </div>
  
</div>


            </div>
            <div class="col-md-10 border vh-100">
    <div class="card mt-3">
        <div class="card-header"></div>
        <div class="card-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
                    
                </div>
            </div>
        </div>
        
    </div>
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH D:\Semester 5\PWL\movieapps\resources\views/layouts/main.blade.php ENDPATH**/ ?>