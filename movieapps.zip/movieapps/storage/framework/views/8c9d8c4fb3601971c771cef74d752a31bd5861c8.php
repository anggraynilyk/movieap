<?php $__env->startSection('title','.:home:.'); ?>
<?php $__env->startSection('content'); ?>
    <h3> home</h3>
    <p>Lorem ipsum dolor sit amet</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layoutss.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Semester 5\PWL\movieapps\resources\views/home.blade.php ENDPATH**/ ?>