<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
          crossorigin="anonymous">

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    <style>
        body {
            overflow-x: hidden;
        }

        /* === Warna senada header === */
        .bg-header {
            background-color: #007bff;
        }

        /* === Sidebar Style === */
        .nav-link {
            color: #333;
            border-radius: 6px;
            margin-bottom: 5px;
            transition: all 0.2s ease;
        }

        .nav-link:hover {
            background-color: #007bff;
            color: white;
        }

        .nav-link.active {
            background-color: #007bff !important;
            color: #fff !important;
            font-weight: bold;
        }

        .card {
            border-radius: 10px;
        }

        .dropdown-menu {
            min-width: 220px;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <!-- HEADER -->
    <div class="row">
        <div class="col-md-12 py-2 bg-header text-white d-flex justify-content-end align-items-center">
            <div class="dropdown">
                <button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    User
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#">
                        <div class="media">
                            <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?fm=jpg&q=60&w=3000"
                                 width="64" height="64" class="align-self-center mr-3 rounded-circle" alt="User">
                            <div class="media-body">
                                <h6 class="mt-0">Anggi 71220917</h6>
                                <small><i class="bi bi-clock"></i> PKL 13.00 WIB</small>
                                <p class="mb-0 text-muted">is urient monteslus mus.</p>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#"><i class="bi bi-gear"></i> Setting</a>
                    <a class="dropdown-item" href="#"><i class="bi bi-box-arrow-right"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- BODY -->
    <div class="row">
        <!-- SIDEBAR -->
        <div class="col-md-2 border vh-100 bg-light">
            <div class="nav flex-column nav-pills mt-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                <a class="nav-link <?php echo e(($key ?? '') == 'home' ? 'active' : ''); ?>" href="/" role="tab">Home</a>
                <a class="nav-link <?php echo e(($key ?? '') == 'movie' ? 'active' : ''); ?>" href="/movie" role="tab">Movie</a>
                <a class="nav-link <?php echo e(($key ?? '') == 'genre' ? 'active' : ''); ?>" href="/genre" role="tab">Genre</a>
                <a class="nav-link <?php echo e(($key ?? '') == 'bioskop' ? 'active' : ''); ?>" href="/bioskop" role="tab">Bioskop</a>
            </div>
        </div>

        <!-- CONTENT -->
        <div class="col-md-10 border vh-100 overflow-auto">
            <div class="card mt-3">
                <div class="card-header bg-light">
                    <h5 class="mb-0"><?php echo $__env->yieldContent('header', 'Dashboard'); ?></h5>
                </div>
                <div class="card-body">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\movieapps\movieapps\resources\views/layouts/main.blade.php ENDPATH**/ ?>