<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;

class MovieSeeder extends Seeder
{
    /**
     * Jalankan seeder untuk tabel movie
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID'); // biar hasil teks-nya lebih natural

        DB::table('movie')->insert([
    'imdb' => 'tt' . $faker->unique()->numberBetween(10000, 99999),
    'title' => $faker->sentence(2),
    'genre' => $faker->randomElement(['Horor', 'Aksi', 'Komedi', 'Drama']),
    'year' => $faker->numberBetween(1980, 2025),
    'description' => $faker->sentence(12),
    'poster' => $faker->imageUrl(300, 450, 'movie', true, 'poster'),
    'created_at' => now(),
    'updated_at' => now(),
]);

    }
}
