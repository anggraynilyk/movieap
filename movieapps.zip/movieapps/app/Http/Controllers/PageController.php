<?php

namespace App\Http\Controllers;

use App\Movie;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function home()
    {
        return view('home', ['key' => 'home']);
    }

    public function movie()
    {
        $movies = Movie::orderBy('id', 'desc')->get();
        return view('movie', ['key' => 'movie', 'mv' => $movies]);
    }

    public function movieaddform()
    {
        return view('movieaddform', ['key' => 'movie']);
    }

    public function movieasave(Request $request)
    {
        // Validasi form
        $request->validate([
            'imdb' => 'nullable|string|max:15',
            'title' => 'required|string|max:255',
            'genre' => 'required|string|max:100',
            'year' => 'required|integer|min:1900|max:' . date('Y'),
            'description' => 'nullable|string',
            'poster' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        // Upload poster
        if ($request->hasFile('poster')) {
            $filename = time() . "_" . $request->file('poster')->getClientOriginalName();
            $path = $request->file('poster')->storeAs('posters', $filename, 'public');
        } else {
            $filename = null;
        }

        // Simpan data ke DB
        Movie::create([
            'imdb' => $request->imdb ?: 'tt' . rand(10000, 99999), // kalau kosong isi otomatis
            'title' => $request->title,
            'genre' => $request->genre,
            'year' => $request->year,
            'description' => $request->description,
            'poster' => $filename
        ]);

        return redirect('/movie')->with('success', 'Data film berhasil disimpan!');
    }

    public function genre()
    {
        return view('genre', ['key' => 'genre']);
    }
}
