@extends('layouts.main')
@section('title', 'Tambah Movie')

@section('content')
<div class="card mt-3">
    <div class="card-header">
        <h3>Tambah Data Film</h3>
    </div>
    <div class="card-body">
        <form action="{{ url('/movie/save') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="mb-3">
                <label for="imdb" class="form-label">IMDB ID (Opsional)</label>
                <input type="text" class="form-control" id="imdb" name="imdb" placeholder="contoh: tt1234567">
            </div>

            <div class="mb-3">
                <label for="title" class="form-label">Judul</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Masukkan judul film" required>
            </div>

            <div class="mb-3">
                <label for="genre" class="form-label">Genre</label>
                <input type="text" class="form-control" id="genre" name="genre" placeholder="Masukkan genre film" required>
            </div>

            <div class="mb-3">
                <label for="year" class="form-label">Tahun Rilis</label>
                <input type="number" class="form-control" id="year" name="year" placeholder="contoh: 2020" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Deskripsi</label>
                <textarea class="form-control" id="description" name="description" rows="3" placeholder="Deskripsi singkat film"></textarea>
            </div>

            <div class="mb-3">
                <label for="poster" class="form-label">Poster</label>
                <input type="file" class="form-control" id="poster" name="poster" accept=".jpg,.jpeg,.png">
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ url('/movie') }}" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
@endsection
