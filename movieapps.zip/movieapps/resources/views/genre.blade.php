@extends('layouts.main')
@section('title', 'Genre')
@section('content')
    <h3>GENRE</h3>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi, voluptatibus!</p>
@endsection
