@extends('layouts.main')
@section('title', 'Movie')

@section('content')
<div class="card">
    <div class="card-header">
        <a href="/movie/addform" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Add Movie
        </a>
    </div>
    <div class="card-body">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>IMDB</th>
                    <th>Title</th>
                    <th>Genre</th>
                    <th>Year</th>
                    <th>Poster</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($mv as $idx => $m)
                <tr>
                    <td>{{ $idx + 1 }}</td>
                    <td>{{ $m->imdb }}</td>
                    <td>{{ $m->title }}</td>
                    <td>{{ $m->genre }}</td>
                    <td>{{ $m->year }}</td>
                    <td>
                        @if ($m->poster)
                            <img src="{{ asset('storage/posters/' . $m->poster) }}" width="80" alt="Poster">
                        @else
                            (no image)
                        @endif
                    </td>
                    <td>
                        <a href="/movie/edit/{{ $m->id }}" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil-square"></i> Edit
                        </a>
                        <form action="/movie/delete/{{ $m->id }}" method="POST" style="display:inline-block;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin mau hapus film ini?')">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
